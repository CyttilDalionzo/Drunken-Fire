function love.conf(t)
    t.window.width = 1200
    t.window.height = 800
    -- A game based on a bad pun. "But, how do I make the arrow shoot into the sky? Well, fire works..."
    t.window.title = "Drunken Fireworks"
    
    t.modules.physics = false
    -- t.modules.joystick = false
end